<?php

$messages = array(
    "home" => "Home",
    "downloads" => "Downloads",
    "docs" => "Documentation",
    "help" => "Getting Help",
    "mailing" => "Mailing Lists",
    "bugs" => "Reporting Bugs",
    "links" => "Links",
    "about" => "About this Demo",
    'accessOf' => 'Access the official site instead',
    'disclaimer' => "Hi, this is a sample application for the %framework%. The purpose of this application is merely academic. This is <b>not</b> an official mirror for PHP. Don\'t trust any information or download any PHP version from this site. %official%. Thanks for visiting us!.",
    'searchFor' => 'Search for...',
    'changeLang' => 'Change Language',
    'conf' => "conferences"
);
