<?php

$messages = array(
    "otherBinaries" => "Binarios para otros Sistemas",
    "otherBinariesEx" => "No distribuimos binarios para UNIX/Linux. La mayoría de distribuciones Linux ya traen PHP hoy en día, así que si no quieres compilarlo desde el código, consulta el sitio web de tu distribución. Algunos binarios están disponibles en servidores externos:",
    "devVersions" => "Versiones de Desarrollo e Históricas",
    "notProduction" => "Tanto las versiones de código como binarios están disponibles en %snaps%. Ninguno de ellos debe ser usado en producción! ",
    "git" => "Para descargar la versión más actualizada de todas, siga las instrucciones usando %git%.",
    "olderReleases" => "Información sobre versiones antiguas y sus descargas están disponibles en la página %releases%. ",
    "sourceCode" => "Código Fuente completo",
    "currentStable" => "Versión estable actual",
    "oldStable" => "Versión estable anterior",
    "otherDownloads" => "Otras Descargas",
    "winBinaries" => "Binarios para Windows",
    "winBinariesEx" => "Encuentre binarios para windows e instaladores en",
    "gnuPg" => "Llaves GPG",
    "gnuPgEx" => "Las versiones han sido etiquetadas y firmadas en el repositorio %git%. Las siguientes llaves Goficiales nuPG  del administrador de versiones actual de PHP pueden usarse para verificar las etiquetas:"
);
