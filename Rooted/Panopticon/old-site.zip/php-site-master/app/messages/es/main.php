<?php

$messages = array(
    "home" => "Inicio",
    "downloads" => "Descargas",
    "docs" => "Documentación",
    "help" => "Obtener Ayuda",
    "mailing" => "Listas de correo",
    "bugs" => "Reportar Problemas",
    "links" => "Enlaces",
    "about" => "Sobre este Demo",
    'accessOf' => 'Ingresa al sitio web oficial',
    'disclaimer' => "Hola!, esta es una aplicación de ejemplo del %framework%. El objetivo de este trabajo es meramente académico. Este sitio no es un espejo del sitio oficial de PHP, además podría estar desactualizado. No confies en la información leída en este sitio, ni descargues versiones desde aquí. %official%. Gracias por tu visita!",
    'searchFor' => 'Buscar',
    'changeLang' => 'Cambiar Idioma',
    'releases' => "lanzamientos",
    'documentation' => "documentación",
    'other' => "otros",
    'testing' => "pruebas",
    'conf' => "conferencias",
    'security' => "seguridad",
);
